package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.ArrayList;
import java.util.List;

public class MobilesPage {
    WebDriver driver;

    private By minPrice = By.id("minPrice");
    private By maxPrice = By.id("maxPrice");
    private By resultsCard = By.xpath("/html/body/div[1]/div[2]/main/div/div/div[2]/div[2]/div/div[2]/div[2]");
    private By resultOne = By.xpath("//*[@id=\"__next\"]/div[2]/main/div/div/div[2]/div[2]/div/div[2]/div[2]/a[1]");
    private By tagName = By.tagName("a");
    private ArrayList<WebElement> mobList = new ArrayList<>();
    private String attr = "";

    public MobilesPage(WebDriver driver){this.driver = driver;}

    public void setMinPrice(String minprice) {
        WebDriverWait wait = new WebDriverWait(driver, 4);
        wait.until(ExpectedConditions.visibilityOfElementLocated((By.id("minPrice"))));
        driver.findElement(minPrice).sendKeys(minprice);
    }

    public void setMaxPrice(String maxprice) {
        WebDriverWait wait = new WebDriverWait(driver, 4);
        wait.until(ExpectedConditions.visibilityOfElementLocated((By.id("maxPrice"))));
        driver.findElement(maxPrice).clear();
        driver.findElement(maxPrice).sendKeys(maxprice);
    }


    public void clickResult(){

        /*WebDriverWait wait = new WebDriverWait(driver, 4);
        wait.until(ExpectedConditions.visibilityOfElementLocated((By.className("card-listing_gridCards__2Q-ZR layout-grid_layoutGrid__lo7JX"))));*/
        //driver.findElement(resultOne).click();

        //List<WebElement> allLinks = driver.findElements((tagName));
        //System.out.println(allLinks.size());
        List<WebElement> allLinks = driver.findElements((tagName));
        System.out.println("No of links are: "+ allLinks.size());

        for (int i =0 ; i < allLinks.size(); i++){
            //String linkTypes = allLinks.get(i).getAttribute("href");
            WebDriverWait wait = new WebDriverWait(driver, 4);
            wait.until(ExpectedConditions.visibilityOfElementLocated((By.xpath("//*[@id=\"__next\"]/div[2]/main/div/div/div[2]/div[2]/div/div[2]/div[2]"))));

            WebElement elm = allLinks.get(i);
            String url = elm.getAttribute("href");

                if(url.contains("products")){
                    driver.get(url);
                    try{Thread.sleep(5000);}
                    catch (InterruptedException ie){}
                    driver.navigate().back();
                }
                else{
                    i++;
                }

            /*if(url.contains("products")){
                driver.get(url);
                try{Thread.sleep(5000);}
                catch (InterruptedException ie){}
                driver.navigate().back();
            }
            else{
                i++;
            }*/

            /*if(attr.contains("products")){
                element.click();
            }
            }

            //List<WebElement> allLinks = driver.findElements((tagName));
            //String linkType = allLinks.get(element).getAttribute("href");

            if(linkType.contains("products")){
                WebElement client = allLinks.get(i);
                client.click();
                //allLinks.get(i).click();
                try{Thread.sleep(5000);}
                catch (InterruptedException ie){}
                driver.navigate().back();
            }*/


            /*if (linkTypes.contains("products")){
                //System.out.println(linkTypes);
                linkTypes.get(i).click();
                driver.navigate().back();
            }*/
        }
    }
}
